while true; do true; done & 
dd if=/dev/zero of=/dev/null & 
