# CPU Utilization Monitoring Script

**Follow Us on Social Networking Sites**
* [Facebook](https://www.facebook.com/Linuxarkit/)
* [Email List](https://feedburner.google.com/fb/a/mailverify?uri=arkit)
* [Linkedin](https://in.linkedin.com/in/ravi-kumar-94530121)
* [Google Plus](https://plus.google.com/u/0/+RedhatEnterpriseLinuxStepbyStepGuide/posts)
* [Twitter](https://twitter.com/aravikumar48)
* [Youtube](https://www.youtube.com/Techarkit?sub_confirmation=1)
* [Email Address](aravikumar48@gmail.com)
* [WhatsApp Group](http://bit.ly/wappg)
* [Linux Telegram Group](http://bit.ly/linux-telegram)
* [Reddit TechTutorials](http://bit.ly/redditark)
* [Tumblr](https://www.tumblr.com/blog/aravikumar48)

Monitor Linux Server CPU Utilization and Get Alerts and also Store Historical CPU Usage Data in Log File.

For more details on this script check below URL

* [Explanantion](https://arkit.co.in/shell-script-to-check-cpu-utilization-in-linux-unix/)
