#!/bin/bash
#Purpose: This is the Sample template File
#Version: 1.0
#Created Date: Thu May 3 11:55:43 IST 2018
#Modified Date:
#Author: Ankam Ravi Kumar
# START #
echo "Testing template file"
# END #
