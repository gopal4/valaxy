#!/bin/bash
#Purpose: One more example for for loop
#Version:
#Created Date: Wed May 16 19:31:50 IST 2018
#Modified Date:
#Author: Ankam Ravi Kumar
# START #
for i in 1 2 3 4 5
do
echo $i
done
# END #
