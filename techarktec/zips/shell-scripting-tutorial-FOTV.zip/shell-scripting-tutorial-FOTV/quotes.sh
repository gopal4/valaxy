#!/bin/bash
#Purpose: Verifying Difference between quotation marks
#Version: 1.0
#Created Date: Fri May 4 20:16:55 IST 2018
#Modified Date:
#Author: Ankam Ravi Kumar
# START #
VAR1=123456
TEST=TechArkit

# Double Quotes
echo "Execute double quotes $VAR1 $TEST"

# Single Quotes
echo 'Excute Single Quotes $VAR1 $TEST'

# Reverse Quotes
echo "This Hostname is: `cal`"

# END #
