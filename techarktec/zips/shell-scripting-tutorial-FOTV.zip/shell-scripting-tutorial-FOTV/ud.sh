#!/bin/bash
#Purpose: eval command Evaluating twice
#Version:1.0
#Created Date: Wed Jun 13 22:09:59 IST 2018
#Modified Date:
#WebSite: https://arkit.co.in
#Author: Ankam Ravi Kumar
# START #

echo "WEl COME TO $USER"
echo " Your present Wroking Directory is `pwd`"
echo "Present Processes are `ps -a`"
echo "Now Time is `date`"
echo "current logged in  Details are `finger $USER`"

# END #
